# Programatic Title Uppercase
------
Programatic change functions for the ai web protocol 